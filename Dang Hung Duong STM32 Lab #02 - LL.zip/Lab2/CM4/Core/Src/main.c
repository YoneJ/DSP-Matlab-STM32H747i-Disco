/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#ifndef HSEM_ID_0
#define HSEM_ID_0 (0U) /* HW semaphore 0*/
#endif

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
uint8_t sel_last_state = GPIO_PIN_RESET;
uint8_t sel_current_state;

uint8_t down_last_state = GPIO_PIN_RESET;
uint8_t down_current_state;

uint8_t left_last_state = GPIO_PIN_RESET;
uint8_t left_current_state;

uint8_t right_last_state = GPIO_PIN_RESET;
uint8_t right_current_state;

uint8_t up_last_state = GPIO_PIN_RESET;
uint8_t up_current_state;

uint8_t led1_state = 0;
uint8_t led2_state = 0;
uint8_t led3_state = 0;
uint8_t led4_state = 0;
uint8_t leds_locked = 0;
uint8_t sel_off = 0;

uint32_t new_global_variable = 12345;

void toggle_led(uint8_t *led_state, uint32_t pin) {
    LL_GPIO_TogglePin(GPIOI, pin);
    *led_state = !(*led_state);
}

void update_led_states(void) {
    LL_GPIO_WriteOutputPin(GPIOI, LED1_Pin, led1_state ? GPIO_PIN_RESET : GPIO_PIN_SET);
    LL_GPIO_WriteOutputPin(GPIOI, LED2_Pin, led2_state ? GPIO_PIN_RESET : GPIO_PIN_SET);
    LL_GPIO_WriteOutputPin(GPIOI, LED3_Pin, led3_state ? GPIO_PIN_RESET : GPIO_PIN_SET);
    LL_GPIO_WriteOutputPin(GPIOI, LED4_Pin, led4_state ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

void update_input_states() {
    down_last_state = down_current_state;
    left_last_state = left_current_state;
    right_last_state = right_current_state;
    up_last_state = up_current_state;
}

void initialize_leds(void) {
    leds_locked = 0;
    led1_state = 0;
    led2_state = 0;
    led3_state = 0;
    led4_state = 1;
    update_led_states();
}

void turn_off_all_leds(void) {
    led1_state = 0;
    led2_state = 0;
    led3_state = 0;
    led4_state = 0;
    update_led_states();
}

void initialize_inputs(void) {
    sel_current_state = LL_GPIO_IsInputPinSet(GPIOK, SEL_Pin);
    down_current_state = LL_GPIO_IsInputPinSet(GPIOK, DOWN_Pin);
    left_current_state = LL_GPIO_IsInputPinSet(GPIOK, LEFT_Pin);
    right_current_state = LL_GPIO_IsInputPinSet(GPIOK, RIGHT_Pin);
    up_current_state = LL_GPIO_IsInputPinSet(GPIOK, UP_Pin);
}

void handle_input(void) {
    initialize_inputs();
    if (leds_locked == 1) {
        return;
    }
    if (down_last_state == GPIO_PIN_RESET && down_current_state == GPIO_PIN_SET) {
        if (led4_state == 1) {
            toggle_led(&led4_state, LED4_Pin);
        } else if (led3_state == 1) {
            toggle_led(&led3_state, LED3_Pin);
        } else if (led2_state == 1) {
            toggle_led(&led2_state, LED2_Pin);
        } else if (led1_state == 1) {
            toggle_led(&led1_state, LED1_Pin);
        }
    }
    if (left_last_state == GPIO_PIN_RESET && left_current_state == GPIO_PIN_SET) {
        uint8_t temp = led1_state;
        led1_state = led4_state;
        led4_state = led3_state;
        led3_state = led2_state;
        led2_state = temp;
        update_led_states();
    }
    if (right_last_state == GPIO_PIN_RESET && right_current_state == GPIO_PIN_SET) {
        uint8_t temp = led1_state;
        led1_state = led2_state;
        led2_state = led3_state;
        led3_state = led4_state;
        led4_state = temp;
        update_led_states();
    }
    if (up_last_state == GPIO_PIN_RESET && up_current_state == GPIO_PIN_SET) {
        if (led1_state == 0) {
            toggle_led(&led1_state, LED1_Pin);
        } else if (led2_state == 0) {
            toggle_led(&led2_state, LED2_Pin);
        } else if (led3_state == 0) {
            toggle_led(&led3_state, LED3_Pin);
        } else if (led4_state == 0) {
            toggle_led(&led4_state, LED4_Pin);
        }
    }
    update_input_states();
}

void lock_leds(void) { leds_locked = 1; }
void unlock_leds(void) { leds_locked = 0; }
void reset_leds(void) {
    led1_state = 0;
    led2_state = 0;
    led3_state = 0;
    led4_state = 0;
    update_led_states();
    leds_locked = 1;
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

/* USER CODE BEGIN Boot_Mode_Sequence_1 */
  /*HW semaphore Clock enable*/
  __HAL_RCC_HSEM_CLK_ENABLE();
  /* Activate HSEM notification for Cortex-M4*/
  HAL_HSEM_ActivateNotification(__HAL_HSEM_SEMID_TO_MASK(HSEM_ID_0));
  /*
  Domain D2 goes to STOP mode (Cortex-M4 in deep-sleep) waiting for Cortex-M7 to
  perform system initialization (system clock config, external memory configuration.. )
  */
  HAL_PWREx_ClearPendingEvent();
  HAL_PWREx_EnterSTOPMode(PWR_MAINREGULATOR_ON, PWR_STOPENTRY_WFE, PWR_D2_DOMAIN);
  /* Clear HSEM flag */
  __HAL_HSEM_CLEAR_FLAG(__HAL_HSEM_SEMID_TO_MASK(HSEM_ID_0));

/* USER CODE END Boot_Mode_Sequence_1 */
  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  /* USER CODE BEGIN 2 */
  reset_leds();
  initialize_leds();
  turn_off_all_leds();
  lock_leds();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
